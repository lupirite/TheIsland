Thanks for downloading my low poly pine tree pack.

The pack includes 3 trees, each with a snowy variant and a matching stump. Three different textures are included to give your trees different looks and styles.

Both .FBX and .OBJ files are included and all models use the same included textures.